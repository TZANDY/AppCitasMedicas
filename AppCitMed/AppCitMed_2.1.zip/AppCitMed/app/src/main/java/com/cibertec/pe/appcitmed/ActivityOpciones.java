package com.cibertec.pe.appcitmed;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class ActivityOpciones extends AppCompatActivity  implements View.OnClickListener{

    Button btnactualizar;
    Button btnfecha;
    EditText edtfecha;
    private int dia , mes,ano;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opciones);
        btnfecha=findViewById(R.id.btn_fecha);
        btnactualizar=findViewById(R.id.btn_actualizar);
        edtfecha=findViewById(R.id.edt_fecha);
        btnfecha.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {
        if(v==btnfecha){
            final Calendar cal = Calendar.getInstance();
            dia= cal.get(Calendar.DAY_OF_MONTH);
            mes=cal.get(Calendar.MONTH);
            ano=cal.get(Calendar.YEAR);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                    edtfecha.setText(dayOfMonth + "/" + (month+1) + "/" + year);
                }
            }
                    ,dia,mes,ano);
            datePickerDialog.show();

        }
        if(v==btnactualizar){

            Intent i = new Intent(ActivityOpciones.this,MenuPrincipal.class);
            startActivity(i);
            Toast.makeText(this,"DATOS ACTUALIZADOS",Toast.LENGTH_LONG).show();

        }
    }
}
