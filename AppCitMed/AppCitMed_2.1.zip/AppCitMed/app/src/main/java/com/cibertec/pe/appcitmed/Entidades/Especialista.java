package com.cibertec.pe.appcitmed.Entidades;

public class Especialista {
    private String _idespecialista;
    private String _nomespecialista;
    private String _apelespecialista;
    private String _idespecialidad;

    public Especialista() {
    }

    public String get_idespecialista() {
        return _idespecialista;
    }

    public void set_idespecialista(String _idespecialista) {
        this._idespecialista = _idespecialista;
    }

    public String get_nomespecialista() {
        return _nomespecialista;
    }

    public void set_nomespecialista(String _nomespecialista) {
        this._nomespecialista = _nomespecialista;
    }

    public String get_apelespecialista() {
        return _apelespecialista;
    }

    public void set_apelespecialista(String _apelespecialista) {
        this._apelespecialista = _apelespecialista;
    }

    public String get_idespecialidad() {
        return _idespecialidad;
    }

    public void set_idespecialidad(String _idespecialidad) {
        this._idespecialidad = _idespecialidad;
    }

    @Override
    public String toString() {
        return "Dr. "+_nomespecialista + " " +_apelespecialista;
    }
}


