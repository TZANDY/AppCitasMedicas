package com.cibertec.pe.appcitmed;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuPrincipalAdministrador extends AppCompatActivity  {
    TextView tvdni;
    TextView tvnombre,tvapellido;
    Button btnActivarPaciente;
    Button btnActivarEspecialista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_administrador);
        tvdni = findViewById(R.id.tv_dni);
        tvnombre = findViewById(R.id.tv_nombre);
        tvapellido = findViewById(R.id.tv_apellido);
        btnActivarPaciente = findViewById(R.id.btn_activarpaciente);
        btnActivarEspecialista = findViewById(R.id.btn_activarespecialista);

        Intent i = this.getIntent();
        final String nombre = i.getStringExtra("nombre");
        final String apellido=i.getStringExtra("apellido");
        final String dni = getIntent().getStringExtra("dni");

        tvnombre.setText(nombre);
        tvapellido.setText(apellido);
        tvdni.setText(dni);
        btnActivarPaciente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuPrincipalAdministrador.this,RegistroPaciente.class);
                startActivity(i);
            }
        });
        btnActivarEspecialista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuPrincipalAdministrador.this,RegistroEspecialista.class);
                startActivity(i);
            }
        });

    }

}
