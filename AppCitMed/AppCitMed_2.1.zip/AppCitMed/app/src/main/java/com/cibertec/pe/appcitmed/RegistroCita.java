package com.cibertec.pe.appcitmed;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.cibertec.pe.appcitmed.Entidades.Especialista;
import com.cibertec.pe.appcitmed.Persistencia.RegistroCitaRequest;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

import cz.msebera.android.httpclient.Header;

public class RegistroCita extends AppCompatActivity  implements View.OnClickListener{

    private static final String CERO = "0";
    private static final String BARRA = "/";
    private static final String DOS_PUNTOS = ":";

    public  final Calendar c = Calendar.getInstance();

    final int mes = c.get(Calendar.MONTH);
    final int dia = c.get(Calendar.DAY_OF_MONTH);
    final int anio = c.get(Calendar.YEAR);

    final int hora = c.get(Calendar.HOUR_OF_DAY);
    final int minuto = c.get(Calendar.MINUTE);

    EditText edtHoraconsulta;
    EditText edtfechaconsulta;
    Button btnpagar;
    ImageButton ibObtenerFecha;
    ImageButton ibObtenerHora;
    ProgressBar progressBar,progressBar2;

    ListView lstespecialistas;
    private AsyncHttpClient cliente;


    RadioButton rbSede1,rbSede2,rbSede3,rbSede4,rbSede5;
    Spinner spnEspecialidad;
    public String especialista;
    public String sede;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_solicitud_uno);
        cliente = new AsyncHttpClient();


        spnEspecialidad=findViewById(R.id.spn_especialidad);
        progressBar=findViewById(R.id.progressBar);
        progressBar2=findViewById(R.id.progressBar2);

        edtfechaconsulta=findViewById(R.id.edt_fechaconsulta);
        edtHoraconsulta=findViewById(R.id.edt_horaconsulta);

        ibObtenerFecha=findViewById(R.id.ib_obtener_fecha);
        ibObtenerFecha.setOnClickListener(this);
        ibObtenerHora=findViewById(R.id.ib_obtener_hora);
        ibObtenerHora.setOnClickListener(this);

        /**SELECCION DE DOCTOR - LISTA*******/
        lstespecialistas=findViewById(R.id.lst_especialistas);


        /****** SELECCION DE SEDE*/
        rbSede1=findViewById(R.id.rb_sede1);
        rbSede2=findViewById(R.id.rb_sede2);
        rbSede3=findViewById(R.id.rb_sede3);
        rbSede4=findViewById(R.id.rb_sede4);
        rbSede5=findViewById(R.id.rb_sede5);

        Intent i = this.getIntent();
        final String vdni = i.getStringExtra("vvdni");
        final String vnombre = i.getStringExtra("vvnommbre");
        final String vapellido = i.getStringExtra("vvapellido");


        ArrayAdapter spnadapter = ArrayAdapter.createFromResource(this,R.array.spnrEspecialidad,R.layout.support_simple_spinner_dropdown_item);
        spnEspecialidad.setAdapter(spnadapter);
        spnEspecialidad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position>0){
                obtenerEspecialistasXespcialidad(position);
                ValidarSedes(position);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        /*****************EVENTO DEL BOTON  [ P A G A R ] ****************/
        btnpagar = findViewById(R.id.btn_pagarXXX);
        btnpagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(rbSede1.isChecked()){
                    sede=rbSede1.getText().toString();
                }
                if(rbSede2.isChecked()){
                    sede=rbSede2.getText().toString();
                }
                if(rbSede3.isChecked()){
                    sede=rbSede3.getText().toString();
                }
                if(rbSede4.isChecked()){
                    sede=rbSede4.getText().toString();
                }
                if(rbSede5.isChecked()){
                    sede=rbSede5.getText().toString();
                }


                String especialidad = spnEspecialidad.getSelectedItem().toString();
                String estado="CONFIRMADO";
                String fecha= edtfechaconsulta.getText().toString();
                String hora = edtHoraconsulta.getText().toString();
                progressBar.setVisibility(View.VISIBLE);

                if(spnEspecialidad.getSelectedItemPosition()!=0){
                    if (!fecha.isEmpty()){
                        if(!hora.isEmpty()){
                                if (!sede.isEmpty()){
                                    Response.Listener<String> respuesta = new Response.Listener<String>()
                                    {
                                        @Override
                                        public void onResponse(String response) {
                                            try {
                                                JSONObject jsonRespuesta = new JSONObject(response);
                                                boolean ok = jsonRespuesta.getBoolean("success");
                                                if(ok=true){
                                                    Intent i = new Intent(RegistroCita.this,MenuPrincipal.class);
                                                    /**##### MANTIENE LAS VARIABLES VIVAS  ####*/
                                                    i.putExtra("nombre",vnombre);
                                                    i.putExtra("apellido",vapellido);
                                                    i.putExtra("dni",vdni);
                                                    progressBar.setVisibility(View.GONE);
                                                    RegistroCita.this.startActivity(i);
                                                    RegistroCita.this.finish();
                                                }
                                                else{
                                                    AlertDialog.Builder alerta = new AlertDialog.Builder(RegistroCita.this);
                                                    alerta.setMessage("ERROR AL GENERAR CITA").setNegativeButton("REINTENTAR",null).create().show();
                                                    progressBar.setVisibility(View.GONE);
                                                }
                                            }
                                            catch (JSONException e){
                                                e.getMessage();
                                                progressBar.setVisibility(View.GONE);
                                            }
                                        }
                                    };
                                    RegistroCitaRequest r = new RegistroCitaRequest(especialidad,especialista,sede,fecha,hora,vdni,estado,respuesta);
                                    RequestQueue cola = Volley.newRequestQueue(RegistroCita.this);
                                    cola.add(r);
                                    Toast.makeText(RegistroCita.this,"Realizado",Toast.LENGTH_LONG).show();
                                }

                                else{Toast.makeText(RegistroCita.this,"Seleccione una sede",Toast.LENGTH_LONG).show();progressBar.setVisibility(View.GONE);}}
                            else{Toast.makeText(RegistroCita.this,"Ingrese la hora",Toast.LENGTH_LONG).show();progressBar.setVisibility(View.GONE);}}
                        else{Toast.makeText(RegistroCita.this,"Ingrese la fecha",Toast.LENGTH_LONG).show();progressBar.setVisibility(View.GONE);}}
                    else{Toast.makeText(RegistroCita.this,"Seleccione una Especialidad",Toast.LENGTH_LONG).show();progressBar.setVisibility(View.GONE);
                }
            }
        });

        /*************************************TERMINA EL EVENTO DEL BOTON************************************/
    }

    /******     M   E   T   O   D   O   S    ********/
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.ib_obtener_fecha:
                obtenerFecha();
                break;
            case R.id.ib_obtener_hora:
                obtenerHora();
                break;
        }
    }

    private void obtenerHora() {
        TimePickerDialog recogerhora = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String horaFormateada=(hourOfDay<10)?String.valueOf(CERO+hourOfDay):String.valueOf(hourOfDay);
                String minutoFormatedo=(minute<10)? String.valueOf(CERO+minute):String.valueOf(minute);
                String am_pm;
                if(hourOfDay<12){am_pm="a.m";}
                else{am_pm="p.m";}
                edtHoraconsulta.setText(horaFormateada+DOS_PUNTOS+minutoFormatedo+" "+am_pm);}
        },hora,minuto,false);
        recogerhora.show();
    }

    private void obtenerFecha() {
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                final int mesActual = month + 1;
                String diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                String mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                edtfechaconsulta.setText(diaFormateado + BARRA + mesFormateado + BARRA + year);
            }
        },anio, mes, dia);
        recogerFecha.show();
    }

    private void obtenerEspecialistasXespcialidad(int idespecialidad){
        progressBar2.setVisibility(View.VISIBLE);
        String url ="https://bdproy.000webhostapp.com/obtenerEspecialistasXespecialidad.php?";
        String parametro= "idespecialidad="+ idespecialidad;
        cliente.post(url + parametro, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                if (statusCode ==200){
                    listarEspecialistaXespecialidad(new String (responseBody));
                    progressBar2.setVisibility(View.GONE);
                }
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {}
        });
    }

    private void listarEspecialistaXespecialidad(String respuesta){
        final ArrayList<Especialista> lista = new ArrayList<>();
        try {
            JSONArray jsonArreglo = new JSONArray(respuesta);
            for (int i = 0; i < jsonArreglo.length(); i++){
                Especialista especialista = new Especialista();
                especialista.set_nomespecialista(jsonArreglo.getJSONObject(i).getString("nombre"));
                especialista.set_apelespecialista(jsonArreglo.getJSONObject(i).getString("apellido"));
                //especialista.set_idespecialidad(jsonArreglo.getJSONObject(i).getString("idespecialidad"));

                lista.add(especialista);
            }
            ArrayAdapter<Especialista> adaptador=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,lista);
            lstespecialistas.setAdapter(adaptador);
            lstespecialistas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    view.setBackgroundColor(Color.DKGRAY);
                    Especialista esp = lista.get(position);
                    especialista=esp.get_nomespecialista()+" "+esp.get_apelespecialista();
                }
            });

        }
        catch (Exception e){e.printStackTrace();}
    }


    private void ValidarSedes(int idsede){

        if(idsede==1||idsede==2||idsede==7||idsede==8||idsede==11||idsede==13){
            rbSede1.setEnabled(true);
            rbSede2.setEnabled(false);
            rbSede3.setEnabled(false);
            rbSede4.setEnabled(true);
            rbSede5.setEnabled(false);
        }
        if(idsede==3||idsede==4||idsede==5||idsede==6){
            rbSede1.setEnabled(true);
            rbSede2.setEnabled(false);
            rbSede3.setEnabled(true);
            rbSede4.setEnabled(true);
            rbSede5.setEnabled(false);
        }
        if(idsede==9||idsede==10||idsede==12){
            rbSede1.setEnabled(false);
            rbSede2.setEnabled(true);
            rbSede3.setEnabled(false);
            rbSede4.setEnabled(true);
            rbSede5.setEnabled(true);
        }


    }

}
