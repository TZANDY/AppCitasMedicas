package com.cibertec.pe.appcitmed;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuPrincipal extends AppCompatActivity {
    Button btnNuevaSolicitud;
    Button btnReferencias;
    TextView tvdni;
    TextView tvnombre,tvapellido;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        tvdni = findViewById(R.id.tv_dni);
        tvnombre = findViewById(R.id.tv_nombre);
        tvapellido = findViewById(R.id.tv_apellido);

        Intent i = this.getIntent();
        final String nombre = i.getStringExtra("nombre");
        final String apellido=i.getStringExtra("apellido");
        final String dni = getIntent().getStringExtra("dni");

        tvnombre.setText(nombre);
        tvapellido.setText(apellido);
        tvdni.setText(dni);


        btnNuevaSolicitud = findViewById(R.id.btn_nuevasolicitud);
        btnNuevaSolicitud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuPrincipal.this,RegistroCita.class);
                i.putExtra("vvdni",dni);
                i.putExtra("vvnommbre",nombre);
                i.putExtra("vvapellido",apellido);
                startActivity(i);
            }
        });
        btnReferencias=findViewById(R.id.btn_referencias);
        btnReferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuPrincipal.this,ListaCita.class);
                i.putExtra("vdni",dni);
                startActivity(i);
            }
        });




    }
   }
