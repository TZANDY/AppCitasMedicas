package com.cibertec.pe.appcitmed;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuPrincipalEspecialista extends AppCompatActivity  {
    TextView tvdni;
    TextView tvnombre,tvapellido;
    Button btnVerCitas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_especialista);
        tvdni = findViewById(R.id.tv_dni);
        tvnombre = findViewById(R.id.tv_nombre);
        tvapellido = findViewById(R.id.tv_apellido);

        Intent i = this.getIntent();
        final String nombre_especialista = i.getStringExtra("nombre");
        final String apellido_especialista=i.getStringExtra("apellido");
        final String dni_especialista = getIntent().getStringExtra("dni");

        tvnombre.setText(nombre_especialista);
        tvapellido.setText(apellido_especialista);
        tvdni.setText(dni_especialista);

        btnVerCitas=findViewById(R.id.btn_vercitas);
        btnVerCitas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MenuPrincipalEspecialista.this,ListaCitaXespecialista.class);
                i.putExtra("vnombreEspecialista",nombre_especialista);
                i.putExtra("vapellidoEspecialista",apellido_especialista);
                startActivity(i);
            }
        });


    }


}
