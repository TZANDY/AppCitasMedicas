package com.cibertec.pe.appcitmed.Entidades;

public class CitaMedica {

    private int _idcita;
    private String _especialidad;
    private String _especialista;
    private String _sede;
    private String _fecha;
    private String _hora;
    private String _dni;
    private String _estado;
    private int _pago;

    public int get_idcita() {
        return _idcita;
    }

    public void set_idcita(int _idcita) {
        this._idcita = _idcita;
    }

    public String get_especialidad() {
        return _especialidad;
    }

    public void set_especialidad(String _especialidad) {
        this._especialidad = _especialidad;
    }

    public String get_especialista() {
        return _especialista;
    }

    public void set_especialista(String _especialista) {
        this._especialista = _especialista;
    }

    public String get_sede() {
        return _sede;
    }

    public void set_sede(String _sede) {
        this._sede = _sede;
    }

    public String get_fecha() {
        return _fecha;
    }

    public void set_fecha(String _fecha) {
        this._fecha = _fecha;
    }

    public String get_hora() {
        return _hora;
    }

    public void set_hora(String _hora) {
        this._hora = _hora;
    }

    public String get_dni() {
        return _dni;
    }

    public void set_dni(String _dni) {
        this._dni = _dni;
    }

    public String get_estado() {
        return _estado;
    }

    public void set_estado(String _estado) {
        this._estado = _estado;
    }

    public int get_pago() {
        return _pago;
    }

    public void set_pago(int _pago) {
        this._pago = _pago;
    }

    public CitaMedica() {
    }

    @Override
    public String toString() {
        return
                "CODIGO DE CITA: " + _idcita +"\n"+
                _especialidad +"\n"+
                "Dr."+_especialista +"\n"+
                _sede +"\n"+
                _fecha +"\n"+
                 _hora +"\n"+
                _estado + "\n"+
                "* Porfavor sea puntual a la cita *";
    }

}

