package com.cibertec.pe.appcitmed.Entidades;

public class Paciente {
    private int _idpaciente;
    private String _nombre;
    private String _apellido;
    private String _dni;
    private String _clave;
    private String _repclave;
    private String _email;
    private String _celular;
    private String _fechanacimiento;
    private String _estadocivil;

    public  Paciente(){}

    public int get_idpaciente() {
        return _idpaciente;
    }

    public void set_idpaciente(int _idpaciente) {
        this._idpaciente = _idpaciente;
    }

    public String get_nombre() {
        return _nombre;
    }

    public void set_nombre(String _nombre) {
        this._nombre = _nombre;
    }

    public String get_apellido() {
        return _apellido;
    }

    public void set_apellido(String _apellido) {
        this._apellido = _apellido;
    }

    public String get_dni() {
        return _dni;
    }

    public void set_dni(String _dni) {
        this._dni = _dni;
    }

    public String get_clave() {
        return _clave;
    }

    public void set_clave(String _clave) {
        this._clave = _clave;
    }

    public String get_repclave() {
        return _repclave;
    }

    public void set_repclave(String _repclave) {
        this._repclave = _repclave;
    }

    public String get_email() {
        return _email;
    }

    public void set_email(String _email) {
        this._email = _email;
    }

    public String get_celular() {
        return _celular;
    }

    public void set_celular(String _celular) {
        this._celular = _celular;
    }

    public String get_fechanacimiento() {
        return _fechanacimiento;
    }

    public void set_fechanacimiento(String _fechanacimiento) {
        this._fechanacimiento = _fechanacimiento;
    }

    public String get_estadocivil() {
        return _estadocivil;
    }

    public void set_estadocivil(String _estadocivil) {
        this._estadocivil = _estadocivil;
    }

    public String toString(){
        return _nombre+"\t"+_apellido+"\t"+_dni;
    }
}
